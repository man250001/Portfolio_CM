@SuppressWarnings("unused")
public class Crossword {

    Square[][] puzzle;
    Clue[] clues;

    FileHandler fh = new FileHandler();
    public Crossword(){
        puzzle = new Square[12][10];
        for (int i = 0; i < puzzle.length; i++){
            for (int j = 0; j < puzzle[0].length; j++){
                puzzle[i][j] = new Square();
            }
        }
        clues = fh.getClues();
        createPuzzle();
    }

    //region Getters and Setters
    public void setPuzzle(Square[][] puzzle) {
        this.puzzle = puzzle;
    }

    public Square[][] getPuzzle() {
        return puzzle;
    }

    public Clue[] getClues() {
        return clues;
    }

    public void setClues(Clue[] clues) {
        this.clues = clues;
    }
    //endregion

    //fills in the puzzle board
    public void createPuzzle(){
        for (Clue c : clues){
            int currentLetInt = 0;
            if (c.getDir().equalsIgnoreCase("v")){
                for (int i = c.getRow(); i < c.getRow() + c.answer.length(); i++){
                    if (currentLetInt == 0){
                        puzzle[i][c.getCol()].setHasNum(true);
                        puzzle[i][c.getCol()].setNum(c.getClueNum());
                    }
                    puzzle[i][c.getCol()].setLetter(c.answer.charAt(currentLetInt));
                    currentLetInt++;
                }
            }else {
                for (int i = c.getCol(); i < c.getCol() + c.answer.length(); i++){
                    if (currentLetInt == 0){
                        puzzle[c.getRow()][i].setHasNum(true);
                        puzzle[c.getRow()][i].setNum(c.getClueNum());
                    }
                    puzzle[c.getRow()][i].setLetter(c.answer.charAt(currentLetInt));
                    currentLetInt++;
                }
            }
        }
        for (Square[] r : puzzle){
            for (Square s : r){
                if (s.getLetter() == ' '){
                    s.setLetter('*');
                    s.setGuessed(true);
                }
            }
        }
    }

    //return the length of the answer of a specified clue
    public int currentClueLength(int index){
        return clues[index].getAnswer().length();
    }

    //Gets the index of a specific clue chosen by the user
    public int getClueIndex(String dir, int num){
        if (dir.equalsIgnoreCase("v")) {
            for (int i = 0; i < clues.length; i++) {
                if (clues[i].getDir().equalsIgnoreCase("v") && clues[i].getClueNum() == num) {
                    return i;
                }
            }
        } else if (dir.equalsIgnoreCase("h")) {
            for (int i = 0; i < clues.length; i++) {
                if (clues[i].getDir().equalsIgnoreCase("h") && clues[i].getClueNum() == num) {
                    return i;
                }
            }
        }
        return -1;
    }

    //prints a specific clue entered by the user
    public void printSpecificClue(int num, String dir){
        if (getClueIndex(dir, num) != -1) {
            System.out.println(clues[getClueIndex(dir, num)]);
        }else {
            System.out.println("Invalid clue");
        }
    }

    //prints all clues horizontal first then vertical
    public void printClues(){
        System.out.println("Horizontal Clues");
        for (Clue c : clues){
            if (c.getDir().equalsIgnoreCase("h")){
                System.out.println(c);
            }
        }
        System.out.println("Vertical Clues");
        for (Clue c : clues){
            if (c.getDir().equalsIgnoreCase("v")){
                System.out.println(c);
            }
        }
    }

    //erases the answer at clue number
    public void eraseAnswer(int num){
        if (num <= clues.length && num > 0) {
            if (clues[num - 1].getDir().equalsIgnoreCase("v")) {
                for (int i = clues[num - 1].getRow(); i < clues[num - 1].getRow() + clues[num - 1].answer.length(); i++) {
                    puzzle[i][clues[num - 1].getCol()].setGuessed(false);
                }
            } else if (clues[num - 1].getDir().equalsIgnoreCase("h")) {
                for (int i = clues[num - 1].getCol(); i < clues[num - 1].getCol() + clues[num - 1].answer.length(); i++) {
                    puzzle[clues[num - 1].getRow()][i].setGuessed(false);
                }
            }
        }
    }

    //Fills in each square if the letter from the guess is correct or not
    public void guessClue(int clueIndex, String guess) {
        int currentLetInt = 0;
        if (clues[clueIndex].getDir().equalsIgnoreCase("v")){
            for (int i = clues[clueIndex].getRow(); i < clues[clueIndex].getRow() + clues[clueIndex].answer.length(); i++){
                if (Character.toLowerCase(puzzle[i][clues[clueIndex].getCol()].getLetter()) == Character.toLowerCase(guess.charAt(currentLetInt))){
                    puzzle[i][clues[clueIndex].getCol()].setGuessed(true);
                }
                currentLetInt++;
            }
        }else if (clues[clueIndex].getDir().equalsIgnoreCase("h")){
            for (int i = clues[clueIndex].getCol(); i < clues[clueIndex].getCol() + clues[clueIndex].answer.length(); i++){
                if (Character.toLowerCase(puzzle[clues[clueIndex].getRow()][i].getLetter()) == Character.toLowerCase(guess.charAt(currentLetInt))){
                    puzzle[clues[clueIndex].getRow()][i].setGuessed(true);
                }
                currentLetInt++;
            }
        }
    }

    //return true if the puzzle is complete else return false
    public boolean isPuzzleSolved(){
        for (Square[] r : puzzle){
            for (Square s : r){
                if (!s.isGuessed()){
                    return false;
                }
            }
        }
        return true;
    }

    //print the puzzle
    public void printPuzzle(){
        for (Square[] r : puzzle){
            for (Square s : r){
                System.out.print(s+" ");
            }
            System.out.println();
        }
    }
}
