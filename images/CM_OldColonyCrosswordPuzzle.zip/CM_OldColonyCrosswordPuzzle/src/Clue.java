@SuppressWarnings("unused")
public class Clue {

    String clue, dir, answer;
    int clueNum, row, col;

    public Clue(int row, int col, String dir, int clueNum, String answer, String clue){
        this.clue = clue;
        this.dir = dir;
        this.clueNum = clueNum;
        this.row = row;
        this.answer = answer;
        this.col = col;
    }

    //region Getters and Setters
    public void setRow(int row) {
        this.row = row;
    }

    public int getClueNum() {
        return clueNum;
    }

    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }

    public String getDir() {
        return dir;
    }

    public void setClueNum(int clueNum) {
        this.clueNum = clueNum;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }

    public String getClue() {
        return clue;
    }

    public void setClue(String clue) {
        this.clue = clue;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
    //endregion

    public String toString() {
        return clueNum + ": " + clue;
    }
}
