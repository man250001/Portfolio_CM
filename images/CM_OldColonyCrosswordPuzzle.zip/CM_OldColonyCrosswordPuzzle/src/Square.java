@SuppressWarnings("unused")
public class Square {

        char letter;
        boolean guessed = false, hasNum;
        int num;

        public Square(){
                letter = ' ';
        }

        //region Getters and Setters
        public boolean isGuessed() {
                return guessed;
        }

        public char getLetter() {
                return letter;
        }

        public void setGuessed(boolean guessed) {
                this.guessed = guessed;
        }

        public void setLetter(char letter) {
                this.letter = letter;
        }

        public boolean isHasNum() {
                return hasNum;
        }

        public int getNum() {
                return num;
        }

        public void setHasNum(boolean hasNum) {
                this.hasNum = hasNum;
        }

        public void setNum(int num) {
                this.num = num;
        }
        //endregion

        public String toString(){
                if (letter == '*'){
                        return "*";
                }
                else if (guessed){
                        return Character.toString(letter);
                }else if (isHasNum()){
                        return Integer.toString(num);
                }
                else
                {
                        return ".";
                }
        }
}
