import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class FileHandler {


    public Clue[] getClues() {
        File file = new File("src/TextFile.txt");

        Scanner inputFile = null;
        try {
            inputFile = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("TextFile.txt Not Found");
            throw new RuntimeException(e);
        }
        ArrayList<Clue> temp = new ArrayList<>();

        while (inputFile.hasNextLine()){
            String[] split = inputFile.nextLine().split(":");
            temp.add(new Clue(Integer.parseInt(split[0]), Integer.parseInt(split[1]), split[2], Integer.parseInt(split[3]), split[4], split[5]));
        }

        Clue[] c = new Clue[temp.size()];
        c = temp.toArray(c);

        return c;
    }
}
