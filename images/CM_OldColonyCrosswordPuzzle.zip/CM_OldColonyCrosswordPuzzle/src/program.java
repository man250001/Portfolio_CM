import java.util.Scanner;

public class program {
    public static Scanner inp = new Scanner(System.in);
    public static void main(String[] args) {

        Crossword mainPuzzle = new Crossword();

        while (true) {
            mainPuzzle.printPuzzle();

            System.out.println("Please Choose an option");
            System.out.println("1. Display all clues");
            System.out.println("2. Display specific clue");
            System.out.println("3. Erase answer");
            System.out.println("4. Submit puzzle");
            System.out.println("5. Exit");
            System.out.println("6. Guess Clue");

            int userInt = inp.nextInt();
            inp.nextLine();
            if (userInt == 1){
                mainPuzzle.printClues();
            } else if (userInt == 2) {
                printClue(mainPuzzle);
            } else if (userInt == 3) {
                eraseAnswer(mainPuzzle);
            } else if (userInt == 4) {
                if (mainPuzzle.isPuzzleSolved()){
                    System.out.println("Puzzle Complete!");
                    break;
                }else {
                    System.out.println("Puzzle Incomplete.");
                }
            } else if (userInt == 5) {
                System.out.println("Exiting...");
                break;
            }else if (userInt == 6) {
                guessClue(mainPuzzle);
            }else {
                System.out.println("Error: Selection was not part of list");
            }
        }
    }

    public static void guessClue(Crossword c){
        System.out.println("Enter a direction h or v");
        String dir = inp.nextLine();

        System.out.println("Enter a clue number");
        int num = inp.nextInt();
        inp.nextLine();

        int index = c.getClueIndex(dir, num);

        if (index > -1){
            System.out.println("Enter a guess");
            String guess = inp.nextLine();
            if (guess.length() == c.currentClueLength(index)){
                c.guessClue(index, guess);
            }else {
                System.out.println("Guess too long/too short");
            }
        }else {
            System.out.println("Invalid clue number/direction");
        }
    }

    //Prints a specific user entered clue
    public static void printClue(Crossword c){
        System.out.println("Enter a dir h (horizontal) or v (virtical) ");
        String dir = inp.nextLine();

        System.out.println("Enter a clue number");
        int num = inp.nextInt();
        inp.nextLine();

        c.printSpecificClue(num, dir);
    }

    //Allows the user to erase an answer
    public static void eraseAnswer(Crossword c){
        System.out.println("Enter a number to erase");
        int num = inp.nextInt();
        inp.nextLine();

        c.eraseAnswer(num);
    }
}
