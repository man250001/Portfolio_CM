module com.example.battleship_cm {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens com.example.battleship_cm to javafx.fxml;
    exports com.example.battleship_cm;
}