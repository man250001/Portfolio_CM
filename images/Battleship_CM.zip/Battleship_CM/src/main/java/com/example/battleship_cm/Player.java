package com.example.battleship_cm;

import java.util.ArrayList;

public class Player {

    ArrayList<Ship> ships = new ArrayList<>();
    Cell[][] board;
    boolean hasShips;
    //Used for row indexes
    String alphabet = "abcdefghijklmnopqrstuvwxyz";

    public Player(Cell[][] board){
        hasShips = true;
        this.board = board;
    }

    public boolean hasLost(){
        for (Ship s : ships) {
            if (!s.hasSunk()) {
                return false;
            }
        }
        return true;
    }

    public Cell[][] getBoard() {
        return board;
    }

    public ArrayList<Ship> getShips() {
        return ships;
    }

    public void setShips(ArrayList<Ship> ships) {
        this.ships = ships;
    }

    public boolean hasShips() {
        return hasShips;
    }

    public void addShip(int length, int colstart, int colend, String rowstart, String rowend) {
        Cell[] shipCells = new Cell[length];
        int count = 0;
        colstart--;
        colend--;
        if (alphabet.contains(rowstart.toLowerCase()) && alphabet.contains(rowend.toLowerCase())
                && colstart <= board[0].length && colstart >= 0 && colend >= 0 && colend <= board[0].length) {
            if (rowstart.equals(rowend)){
                while (count != length){
                    if (board[alphabet.indexOf(rowstart)][colstart + count].hasShip){
                        return;
                    }else {
                        shipCells[count] = board[alphabet.indexOf(rowstart)][colstart + count];
                    }
                    count++;
                }
            }else {
                while (count != length){
                    if (board[alphabet.indexOf(rowstart) + count][colstart].hasShip){
                        return;
                    }else {
                        shipCells[count] = board[alphabet.indexOf(rowstart) + count][colstart];
                    }
                    count++;
                }
            }
            ships.add(new Ship(length, shipCells));
            for (Cell c : shipCells){
                c.setHasShip(true);
            }
        }else {
            System.out.println("Ship out of bounds!");
        }
    }

    //Returns true if attack succeeded, false if cell was already hit or does not exist
    public boolean attackCell(int column, String row) {
        column--;
        if (alphabet.contains(row.toLowerCase()) && column <= board[0].length && column >= 0) {
            Cell attackedCell = board[alphabet.indexOf(row.toLowerCase())][column];
            if(!attackedCell.isHit) {
                attackedCell.setHit(true);
                if (attackedCell.hasShip) {
                    System.out.println("Hit Ship!");
                    for (Ship s : ships){
                        s.checkSunk();
                    }
                } else {
                    System.out.println("Miss...");
                }
                return true;
            }else {
                System.out.println("Already hit cell.");
                return false;
            }
        }
        System.out.println("Attack Failed.");
        return false;
    }

    public void printBoard(){
        String row = "";
        System.out.print("  ");
        for (int i = 0; i < board.length; i++){
            System.out.print((i + 1) + " ");
        }
        System.out.println();
        for (int i = 0; i < board.length; i++) {
            System.out.print(Character.toString(alphabet.charAt(i)) + " ");
            for (int j = 0; j < board[0].length; j++) {
                row = row + board[i][j] + " ";
            }
            System.out.print(row);
            System.out.println();
            row = "";
        }
    }

    public void printEnemyBoard(){
        String row = "";
        System.out.print("  ");
        for (int i = 0; i < board.length; i++){
            System.out.print((i + 1) + " ");
        }
        System.out.println();
        for (int i = 0; i < board.length; i++) {
            System.out.print(Character.toString(alphabet.charAt(i)) + " ");
            for (int j = 0; j < board[0].length; j++) {
                row = row + board[i][j].gameCell() + " ";
            }
            System.out.print(row);
            System.out.println();
            row = "";
        }
    }
}
