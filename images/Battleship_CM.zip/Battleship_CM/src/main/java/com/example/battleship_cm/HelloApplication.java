package com.example.battleship_cm;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Scanner;

public class HelloApplication extends Application {

    public final static String DELIMITER = "\n";

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        String alphabet = "abcdefghijklmnopqrstuvwxyz";
        Cell[][] Baseboard = new Cell[10][10];
        Cell[][] Baseboard2 = new Cell[10][10];
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < Baseboard.length; i++) {
            for (int j = 0; j < Baseboard[0].length; j++) {
                Baseboard[i][j] = new Cell(j + 1, Character.toString(alphabet.charAt(i)));
            }
        }
        for (int i = 0; i < Baseboard2.length; i++) {
            for (int j = 0; j < Baseboard2[0].length; j++) {
                Baseboard2[i][j] = new Cell(j + 1, Character.toString(alphabet.charAt(i)));
            }
        }
        Player player1 = new Player(Baseboard);
        Player player2 = new Player(Baseboard2);


        placeShips(alphabet, Baseboard, player1);

        System.out.println(DELIMITER.repeat(100));

        placeShips(alphabet, Baseboard2, player2);

        System.out.println(DELIMITER.repeat(100));
        while (!player1.hasLost() && !player2.hasLost()) {
            System.out.println("Player 1 get ready to fire.");
            player2.printEnemyBoard();
            System.out.println("Enter a row to fire on: ");
            String row = input.nextLine();
            System.out.println("Enter a column to fire on: ");
            int col = input.nextInt();
            input.nextLine();
            while (true) {
                if (!player2.attackCell(col, row)) {
                    player2.printEnemyBoard();
                    System.out.println("Enter a new row to fire on: ");
                    row = input.nextLine();
                    System.out.println("Enter a new column to fire on: ");
                    col = input.nextInt();
                    input.nextLine();
                } else {
                    break;
                }
            }

            if (player2.hasLost()){
                break;
            }
            System.out.println("Player 2 get ready to fire.");
            player1.printEnemyBoard();
            System.out.println("Enter a row to fire on: ");
            row = input.nextLine();
            System.out.println("Enter a column to fire on: ");
            col = input.nextInt();
            input.nextLine();
            while (true) {
                if (!player1.attackCell(col, row)) {
                    player1.printEnemyBoard();
                    System.out.println("Enter a new row to fire on: ");
                    row = input.nextLine();
                    System.out.println("Enter a new column to fire on: ");
                    col = input.nextInt();
                    input.nextLine();
                } else {
                    break;
                }
            }
        }

        if (player1.hasLost()){
            System.out.println("Player 2 Wins!");
        }else {
            System.out.println("Player 1 Wins!");
        }
    }

    private static void placeShips(String alphabet, Cell[][] baseboard, Player player) {
        int count = 2;
        boolean placedThree = false;
        Scanner input = new Scanner(System.in);
        while (count <= 5) {
            player.printBoard();
            System.out.println("Enter a row to place your " + count + " ship");
            String shipRow = input.nextLine();
            System.out.println("Enter a col to place your " + count + " ship");
            int shipCol = input.nextInt();
            input.nextLine();
            while (true) {
                if ((shipCol <= baseboard[0].length && shipCol >= 0) && (alphabet.indexOf(shipRow) >= 0 && alphabet.indexOf(shipRow) <= baseboard.length)) {
                    break;
                }
                System.out.println("Error Ship out of bounds enter a new starting point.");
                System.out.println("Enter a row to place your " + count + " ship");
                shipRow = input.nextLine();
                System.out.println("Enter a col to place your " + count + " ship");
                shipCol = input.nextInt();
                input.nextLine();
            }

            System.out.println("Which direction should the ship go? (Up, Down, Left, Right");
            String shipDir = input.nextLine().toLowerCase();
            while (true) {
                if (shipDir.equals("up") || shipDir.equals("down") || shipDir.equals("left") || shipDir.equals("right")) {
                    break;
                }
                System.out.println("Which direction should the ship go? (Up, Down, Left, Right");
                shipDir = input.nextLine().toLowerCase();
            }


            count = placeValidShip(alphabet, player, count, shipRow, shipCol, shipDir, baseboard);
            if (count == 4 && !placedThree){
                placedThree = true;
                count--;
            }
        }
    }

    private static int placeValidShip(String alphabet, Player test, int count, String shipRow, int shipCol, String shipDir, Cell[][] Baseboard) {
        Scanner input = new Scanner(System.in);
        String rowEnd = "";
        int colEnd = 0;
        if (shipDir.equals("up")) {
            rowEnd = shipRow;
            if (alphabet.indexOf(shipRow) - (count - 1) < 0) {
                System.out.println("Error Ship out of bounds enter a new direction.");
                System.out.println("Which direction should the ship go? (Up, Down, Left, Right");
                shipDir = input.nextLine().toLowerCase();
                placeValidShip(alphabet, test, count, shipRow, shipCol, shipDir, Baseboard);
            }else {
                shipRow = Character.toString(alphabet.charAt(alphabet.indexOf(shipRow) - (count - 1)));
                colEnd = shipCol;
                test.addShip(count, shipCol, colEnd, shipRow, rowEnd);
                count++;
            }
        } else if (shipDir.equals("right")) {
            if (shipCol + (count - 1) > Baseboard[0].length) {
                System.out.println("Error Ship out of bounds enter a new direction.");
                System.out.println("Which direction should the ship go? (Up, Down, Left, Right");
                shipDir = input.nextLine().toLowerCase();
                placeValidShip(alphabet, test, count, shipRow, shipCol, shipDir, Baseboard);
            }else {
                colEnd = shipCol + (count - 1);
                rowEnd = shipRow;
                test.addShip(count, shipCol, colEnd, shipRow, rowEnd);
                count++;
            }
        } else if (shipDir.equals("left")) {
            if (shipCol - (count - 1) < 0) {
                System.out.println("Error Ship out of bounds enter a new direction.");
                System.out.println("Which direction should the ship go? (Up, Down, Left, Right");
                shipDir = input.nextLine().toLowerCase();
                placeValidShip(alphabet, test, count, shipRow, shipCol, shipDir, Baseboard);
            }else {
                colEnd = shipCol;
                shipCol = shipCol - (count - 1);
                rowEnd = shipRow;
                test.addShip(count, shipCol, colEnd, shipRow, rowEnd);
                count++;
            }
        }else {
            if (alphabet.indexOf(shipRow) + (count - 1) > Baseboard.length){
                System.out.println("Error Ship out of bounds enter a new direction.");
                System.out.println("Which direction should the ship go? (Up, Down, Left, Right");
                shipDir = input.nextLine().toLowerCase();
                placeValidShip(alphabet, test, count, shipRow, shipCol, shipDir, Baseboard);
            }else {
                rowEnd = Character.toString(alphabet.charAt(alphabet.indexOf(shipRow) + (count - 1)));
                colEnd = shipCol;
                test.addShip(count, shipCol, colEnd, shipRow, rowEnd);
                count++;
            }
        }
        return count;
    }
}