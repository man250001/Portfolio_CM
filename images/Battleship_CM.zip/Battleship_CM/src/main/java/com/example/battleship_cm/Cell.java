package com.example.battleship_cm;

public class Cell {

    boolean isHit, hasShip;
    int column;
    String row;
    //Used for row indexes
    String alphabet = "abcdefghijklmnopqrstuvwxyz";

    public Cell(int c, String r){
        column = c;
        row = r;
    }

    public boolean wasHit(){
        return isHit;
    }

    public boolean hasShip(){
        return hasShip;
    }

    public void setHasShip(boolean _hasShip){
        hasShip = _hasShip;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public String getRow() {
        return row;
    }

    public int getRowNum() {
        return alphabet.indexOf(row);
    }

    public void setRow(String row) {
        this.row = row;
    }

    public void setHit(boolean hit) {
        isHit = hit;
    }

    public String toString() {
        if (!hasShip && !isHit){
            return "-";
        }else if (!hasShip && isHit) {
            return "o";
        }else if (hasShip && !isHit) {
            return "s";
        }else {
            return "\u001b[31mx\u001b[0m";
        }
    }

    public String gameCell() {
        if (!hasShip && !isHit){
            return "-";
        }else if (!hasShip && isHit) {
            return "o";
        }else if (hasShip && isHit) {
            return "\u001b[31mx\u001b[0m";
        }else {
            return "-";
        }
    }
}
