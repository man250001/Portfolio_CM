package com.example.battleship_cm;

public class Ship {

    int length;
    Cell[] cells;
    boolean hasSunk;

    public Ship(int length, Cell[] cells){
        this.length = length;
        this.cells = cells;
        hasSunk = false;
    }

    public Cell[] getCells() {
        return cells;
    }

    public int getLength() {
        return length;
    }

    public boolean hasSunk() {
        return hasSunk;
    }

    public void checkSunk() {
        hasSunk = true;
        for (Cell c : cells) {
            if (!c.isHit){
                hasSunk = false;
            }
        }
    }

    public void setHasSunk(boolean hasSunk) {
        this.hasSunk = hasSunk;
    }

    public void setLength(int length) {
        this.length = length;
    }
}
